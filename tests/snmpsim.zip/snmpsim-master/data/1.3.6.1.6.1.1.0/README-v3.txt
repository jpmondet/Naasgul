This directory serves as a special case when Simulator is NOT running
in --v2c-arch mode.

This is a ContextName AND transport domain specific directory.

The .snmprec files in this directory would be used by Simulator whenever
ContextName in request is empty AND transport domain AND source address
being used matches the .snmprec filename.
