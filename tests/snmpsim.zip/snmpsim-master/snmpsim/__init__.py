# http://www.python.org/dev/peps/pep-0396/
__version__ = '1.0.0'
